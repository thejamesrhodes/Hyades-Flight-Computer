# Roll-control design & verification (MATLAB / Simulink)

Design and Monte-Carlo verification of the **roll-rate damping** channel for the
Hyades canard-controlled high-power rocket. Built with **MATLAB R2025b**
(Simulink). This is the roll-axis slice of the wider GNC work: a single-input
single-output rate loop with a dynamic-pressure-scheduled gain, plus the
stochastic robustness analysis used to pick that gain.

> Scope note: connectivity between these scripts and the binary `.slx` models is
> documented from the **driving scripts** (logged signal names, the parameter
> struct `P`). The internals of the Simulink models are not reproduced here in
> text form — open them in Simulink to inspect the block diagram.

---

## Control law

Pure proportional roll-rate damping with a $1/\bar q$ gain schedule:

$$\delta_\mathrm{cmd} = -K_p(\bar q)\,p, \qquad K_p(\bar q) = \frac{c}{\bar q}$$

Optional integral action is available in the Simulink controller via `Controller.Ti`
(ratio of integral to proportional gain); the standalone frequency-domain design
script `optimise_roll_schedule.m` treats the **pure proportional** case.

The single-axis roll plant is modelled as

$$\dot p = a\,p + b\,\delta, \qquad b = k_b\,\bar q,\quad a = k_a\,\frac{\bar q}{V},$$

$$k_b = \frac{A\,d\,C_{l\delta}}{I_{xx}}, \qquad k_a = \frac{A\,d^2\,C_{l_p}}{2\,I_{xx}}\ (<0).$$

with the actuator modelled as a second-order lag plus transport delay,
$H_\mathrm{act}(s) = \dfrac{\omega_n^2}{s^2 + 2\zeta\omega_n s + \omega_n^2}\,e^{-s\tau_d}$.

**Design quantity.** The $1/\bar q$ schedule holds the **open-loop crossover**
constant, $\omega_c = C\,k_b$, which is what the schedule targets — *not* the
closed-loop $-3\,\mathrm{dB}$ bandwidth (that also depends on the plant pole
$|a|=|k_a|\bar q/V$ and varies strongly across the envelope when passive damping
$C_{l_p}$ is large). The analytic schedule constant is $C_0 = \omega_\mathrm{target}/k_b$.

where
- $\delta$ — canard deflection command / rad
- $p$ — roll rate / rad s⁻¹
- $\bar q$ — dynamic pressure / Pa
- $V$ — airspeed / m s⁻¹
- $A$ — body reference (cross-sectional) area / m² ($=\pi d^2/4$)
- $d$ — body diameter / m
- $I_{xx}$ — roll moment of inertia / kg m²
- $C_{l\delta}$ — roll control effectiveness / rad⁻¹
- $C_{l_p}$ — non-dimensional roll damping derivative
- $c,\,C$ — proportional schedule constant (gain $=c/\bar q$)
- $\omega_n,\,\zeta,\,\tau_d$ — actuator natural frequency / rad s⁻¹, damping ratio, transport delay / s
- $\omega_c,\,\omega_\mathrm{target}$ — open-loop crossover and its design target / rad s⁻¹

**Sign / unit conventions:** SI throughout; all angles and rates in radians.
$C_{l_p}<0$ is passively stabilising. There is no setpoint integral in the pure
rate damper (rate damping has no steady-state setpoint error); a standing roll
bias is cancelled by **feed-forward of $C_{l0}$**, not integral action.

---

## Files and how they fit together

```
parameters_initialise_roll_control.m   nominal parameter struct P (aero/vehicle/servo/controller)
        │
        ├── optimise_roll_schedule.m         standalone: frequency-domain design of C.
        │                                    No Simulink, no toolboxes. Margin/robustness
        │                                    of the crossover schedule to ±30% Cl_delta, Cl_p.
        │
        └── Simulink_Roll_Model_1.slx        the roll plant + controller (logs p_log, delta_real_log)
                    │
                    ├── montecarlo_roll_control.m      dispersion analysis of the model:
                    │                                  samples P, runs N sims, extracts metrics,
                    │                                  reports pFail + sensitivity plots
                    │
                    └── parameter_sweep_roll_control.m  wraps the Monte Carlo over a (c, Ti) grid
                                                        with common random numbers; heatmaps / knee plots
```

| File | Role | Toolboxes |
|---|---|---|
| `parameters_initialise_roll_control.m` | Returns nominal `P` (single source of truth for constants). | — |
| `optimise_roll_schedule.m` | Analytic $C_0$ + numerical margin check (PM/GM/$M_s$) across the $(\bar q, V)$ envelope under independent ±30% $C_{l\delta}$ and $C_{l_p}$. Pure frequency response, exact delay. | none (self-contained) |
| `montecarlo_roll_control.m` | Monte-Carlo / LHS dispersion of the Simulink model; per-run metrics (settling, overshoot, peak deflection), $P_\mathrm{fail}$, and SRC / point-biserial sensitivity. | Simulink (req); Control System (`stepinfo`); Parallel Computing (opt); Statistics (opt, LHS/`gplotmatrix`). |
| `parameter_sweep_roll_control.m` | Deterministic sweep of design gains `Controller.c`, `Controller.Ti`, Monte Carlo nested at each point with a fixed seed (CRN). 1-D knee plots or 2-D heatmaps. | as above |
| `models/Simulink_Roll_Model_1.slx` | Roll plant + scheduled controller. Consumes `P`; logs `p_log` (rate), `delta_real_log` (deflection). | Simulink |

`figures/` holds the committed output plots: `heatmaps/` (2-D `c×Ti` sweep
metrics), `step-response/`, and `other/`. These are **generated artifacts** —
regenerate by running the scripts; see the note in `.gitignore` if you would
rather not version them.

---

## Running

```matlab
% from simulation/roll-control/
P = parameters_initialise_roll_control;     % inspect / edit nominal parameters

optimise_roll_schedule                      % frequency-domain schedule design (standalone)

R = montecarlo_roll_control();              % single-point dispersion at nominal gains
                                            % (edit the CONFIG block: model name, N, seed,
                                            %  logged-signal names, servo limit)

% gain sweeps (Monte Carlo nested at each grid point, common random numbers):
sweep = parameter_sweep_roll_control(50:50:300);                 % c only (1-D)
sweep = parameter_sweep_roll_control(50:50:300, 2:2:12, 200, 2025, 0.5);  % c×Ti (2-D)
```

The Simulink model must be on the MATLAB path (add `models/` or open the model
first); `montecarlo_roll_control.m` calls `load_system('Simulink_Roll_Model_1')`.

---

## Reproducibility

- Fixed RNG **seed** (default `2025`) is recorded in the Monte-Carlo `cfg` and
  reused at every sweep grid point (common random numbers), so differences
  across gains are attributable to the gains, not sampling noise.
- Dispersions (`cfg.disp_spec`) are declared explicitly with per-parameter type
  (`rel_gauss` / `abs_gauss`), spread, and a physical clip guard.
- Record the seed, `N`, and the sampler (`mc` / `lhs`) alongside any result.

## Known caveats (carried from the source comments)

- **Crossover ≠ closed-loop bandwidth.** The schedule fixes $\omega_c=C k_b$; the
  realised closed-loop bandwidth varies across the envelope. Read `optimise_roll_schedule.m`.
- **Roll axis is the least trustworthy for model inversion.** $C_{l\delta}$ can be
  small and can change sign with angle of attack and Mach; a sign error is the
  most dangerous roll-axis failure. Confirm `C_opt` in a **nonlinear** sim
  (saturation + rate limit) before use, as the script prints.
- **Regulator `stepinfo`.** For `ref = 0`, `stepinfo` is called with an explicit
  initial value `p(1)`; the divergence threshold is scaled by
  $\max(|\text{ref}|, |p_0|)$ so a decaying regulator is handled correctly.
