# Integrating this into Hyades-Active-Control-System---fc

The repo is a flat "most relevant files" collection (Apache-2.0). This bundle
adds a `simulation/` subtree; nothing here conflicts with existing paths.

## Merge

Copy `simulation/` to the repo root. Merge `.gitignore` and `.gitattributes`
into the repo root (create them if absent — the repo currently has neither).

```
simulation/
  roll-control/   MATLAB/Simulink roll-rate damper design + Monte Carlo
  landing/        standalone landing Simulink model
```

## Notes / things to decide

- **License headers.** The repo license is Apache-2.0. The `kicad10-parse.zip`
  already in the repo carries an MIT `LICENSE` inside it — inconsistent with the
  repo's Apache-2.0. Worth reconciling (pick one, or add an explicit per-module
  license note). This bundle adds no license file, so it inherits Apache-2.0.
- **`.asv` autosaves were excluded** (`optimise_roll_schedule.asv`,
  `parameters_initialise_roll_control.asv`) — they are MATLAB editor backups,
  not source.
- **Figures are committed** as reference output (~2 MB, 30 PNGs). If you prefer
  a clean history, keep a curated few in the README and ignore the rest (see the
  commented rule in `.gitignore`).
- **Code inconsistency to fix** (not touched here — files copied verbatim):
  in `optimise_roll_schedule.m` the header comment reasons about
  `Cl_p = -5.778` (roll pole "~0.4 to ~55 rad/s", "~8.7 Hz"), but the code sets
  `Cl_p_nom = -1.18`. The narrative numbers were derived for a different damping
  value than the code uses — reconcile the comment and the constant.
