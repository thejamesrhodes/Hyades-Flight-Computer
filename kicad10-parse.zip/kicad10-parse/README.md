# kicad10-parse

A small, **dependency-free** (Python stdlib only) reader for **KiCad 10**
schematic (`.kicad_sch`) and board (`.kicad_pcb`) files. Written because
off-the-shelf libraries did not yet support the KiCad 10 file format
(sch `20260306`, pcb `20260206`) at the time.

## Why it exists / the one load-bearing format fact

KiCad 10 **dropped the integer net table**. The net *name* is stored directly
on every pad, track, via and zone as `(net "NAME")` — a single string, no
numeric code, and there is no top-level net-code lookup table. Everything here
treats that net name as the ground truth for connectivity.

## Install

```bash
pip install -e .        # editable install, exposes the CLIs below
# or just run in place, no install needed (stdlib only):
python -m kicad10_parse.pcb board.kicad_pcb
```

## Modules / CLIs

| Module | Console script | Purpose |
|---|---|---|
| `kicad10_parse.sexp` | — | S-expression tokenizer + reader; helpers `load/head/children/get1/args/val/find_all`. |
| `kicad10_parse.schematic` | `kicad10-sch` | Components (ref/value/footprint/extra fields), hierarchical sheets, labels. |
| `kicad10_parse.libpins` | `kicad10-libpins` | Pin-number → pin-name tables from `lib_symbols` (recurses sub-units). |
| `kicad10_parse.pcb` | `kicad10-pcb` | Netlist (`net → [(ref,pad)]`), footprints, zones, stackup, board bbox, track/via summary. |
| `kicad10_parse.pinmap` | `kicad10-pinmap` | **Join**: IC pad → pin-name → net. The "what's actually on STM32 pin PA9 / VCAP / BOOT0" view. |

## Usage

```bash
# Board-level summary + full netlist JSON
python -m kicad10_parse.pcb  board.kicad_pcb  board.json

# IC pin tables (symbols with >= 6 pins)
python -m kicad10_parse.libpins  *.kicad_sch

# Component / sheet / label dump as JSON
python -m kicad10_parse.schematic  root.kicad_sch sub1.kicad_sch > sch.json

# The useful one: pin-function -> net for specific parts
python -m kicad10_parse.pinmap \
    --pcb board.kicad_pcb \
    --sch root.kicad_sch sub1.kicad_sch \
    U1 U4        # omit refs to print every multi-pin IC
```

### As a library

```python
from kicad10_parse.pcb import extract as pcb_extract
from kicad10_parse.pinmap import build

netlist = pcb_extract("board.kicad_pcb")["net_pads"]        # {net: [(ref,pad)]}
pins    = build("board.kicad_pcb", ["root.kicad_sch"])       # {ref: [(pad,name,net)]}
for pad, name, net in pins["U1"]:
    print(pad, name, net)
```

## Scope and limitations

- **Connectivity is read from resolved net assignments on pads**, i.e. it is
  ground truth *as annotated on the PCB*. It is **not** re-derived from
  schematic wire geometry. This is correct when the board has been updated
  from the schematic; it will **not** catch a schematic net that was never
  pushed to the layout. For a pure schematic-only netlist you would need to
  add geometric wire tracing to `schematic.py`, which this does not do.
- The parser is **format-agnostic** (it tokenizes any KiCad S-expression), but
  the *extractors* assume the KiCad 10 layout of specific nodes (layers,
  zones, pad nets). A future format bump may move fields and require small
  edits to the extractor functions — not the tokenizer.
- No geometric DRC: clearances, controlled-impedance geometry, thermal relief,
  and copper current-carrying capacity are out of scope.

## License

MIT — edit the placeholder in `LICENSE` before publishing.
