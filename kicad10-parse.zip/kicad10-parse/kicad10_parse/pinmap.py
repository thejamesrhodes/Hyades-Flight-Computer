"""Join IC pin functions to nets: for each component, map pad number -> pin
name (from the schematic's lib_symbols) -> net (from the PCB net assignments).

This is the "what is actually connected to STM32 pin PA9 / VCAP / BOOT0"
view that makes a raw netlist reviewable.

CLI:
  python -m kicad10_parse.pinmap --pcb board.kicad_pcb \
         --sch root.kicad_sch [sub.kicad_sch ...] [REF ...]

If REFs are given, only those are printed; otherwise every component whose
library symbol has >= 6 pins is printed.
"""
import sys
from . import schematic, libpins
from .pcb import extract as pcb_extract, pad_to_net


def build(pcb_path, sch_paths):
    """Return {ref: [(pad, pin_name, net), ...]} sorted by pad."""
    ref2lib = schematic.ref_to_lib(sch_paths)
    libs = libpins.tables_for(sch_paths)
    p2n = pad_to_net(pcb_extract(pcb_path))
    result = {}
    for ref, lib in ref2lib.items():
        pins = libs.get(lib)
        if pins is None:  # fall back to matching on the part after the ':'
            short = lib.split(':')[-1]
            for k, v in libs.items():
                if k.split(':')[-1] == short:
                    pins = v; break
        if not pins:
            continue
        rows = [(pad, name, p2n.get((ref, pad), None))
                for pad, name in pins.items()]
        rows.sort(key=lambda r: (len(str(r[0])), str(r[0])))
        result[ref] = rows
    return result


def _parse_args(argv):
    pcb = None; sch = []; refs = []; mode = None
    for a in argv:
        if a == '--pcb':
            mode = 'pcb'
        elif a == '--sch':
            mode = 'sch'
        elif mode == 'pcb':
            pcb = a; mode = None
        elif mode == 'sch':
            sch.append(a)  # stays in sch mode: consumes following sch files
        else:
            refs.append(a)
    # allow bare REFs to appear after --sch list by treating non-file tokens as refs
    real_sch = [s for s in sch if s.endswith(('.kicad_sch',))]
    refs += [s for s in sch if not s.endswith(('.kicad_sch',))]
    return pcb, real_sch, refs


def main(argv=None):
    argv = argv or sys.argv[1:]
    pcb, sch, refs = _parse_args(argv)
    if not pcb or not sch:
        print(__doc__.strip()); return 2
    mp = build(pcb, sch)
    keys = refs if refs else sorted(mp, key=lambda r: (len(mp[r]) < 6, r))
    for ref in keys:
        rows = mp.get(ref)
        if not rows:
            print(f"# {ref}: not found / no pin table"); continue
        if not refs and len(rows) < 6:
            continue
        print(f"===== {ref} =====")
        for pad, name, net in rows:
            print(f"  pad {str(pad):>3} | {str(name):22} | {net if net else '--unconnected--'}")
        print()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
