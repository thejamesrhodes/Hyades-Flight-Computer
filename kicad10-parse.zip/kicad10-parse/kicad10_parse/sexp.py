# SPDX-License-Identifier: Apache-2.0
"""Minimal robust KiCad S-expression parser (stdlib only).

Tokenizer + recursive-descent reader. Handles CRLF line endings and quoted
string escapes. Nodes are Python lists; scalar tokens are ('STR', value) or
('ATOM', value) tuples. This is format-agnostic: it will tokenize any KiCad
S-expression file regardless of format version.
"""
import sys


def tokenize(s):
    toks = []; i = 0; n = len(s)
    while i < n:
        c = s[i]
        if c in ' \t\r\n':
            i += 1; continue
        if c == '(':
            toks.append('('); i += 1; continue
        if c == ')':
            toks.append(')'); i += 1; continue
        if c == '"':
            i += 1; buf = []
            while i < n:
                c = s[i]
                if c == '\\':
                    nx = s[i + 1]
                    buf.append({'n': '\n', 't': '\t', 'r': '\r', '"': '"', '\\': '\\'}.get(nx, nx))
                    i += 2; continue
                if c == '"':
                    i += 1; break
                buf.append(c); i += 1
            toks.append(('STR', ''.join(buf))); continue
        # bare atom
        buf = []
        while i < n and s[i] not in ' \t\r\n()"':
            buf.append(s[i]); i += 1
        toks.append(('ATOM', ''.join(buf)))
    return toks


def parse(toks):
    pos = [0]

    def rd():
        t = toks[pos[0]]; pos[0] += 1
        if t == '(':
            lst = []
            while toks[pos[0]] != ')':
                lst.append(rd())
            pos[0] += 1
            return lst
        if t == ')':
            raise ValueError('unexpected )')
        return t  # ('STR', v) or ('ATOM', v)

    return rd()


def load(path):
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        return parse(tokenize(f.read()))


def val(node):
    """Scalar value of a token tuple (or the node itself if already scalar)."""
    return node[1] if isinstance(node, tuple) else node


def head(node):
    """First element (the 'keyword') of an S-expression list, or None."""
    if isinstance(node, list) and node:
        h = node[0]
        return h[1] if isinstance(h, tuple) else h
    return None


def find_all(node, name):
    """Recursively collect every sub-list whose head == name."""
    out = []
    if isinstance(node, list):
        if head(node) == name:
            out.append(node)
        for c in node:
            out.extend(find_all(c, name))
    return out


def children(node, name):
    """Direct child lists whose head == name (non-recursive)."""
    out = []
    if isinstance(node, list):
        for c in node[1:]:
            if isinstance(c, list) and head(c) == name:
                out.append(c)
    return out


def get1(node, name):
    """First direct child with head == name, or None."""
    c = children(node, name)
    return c[0] if c else None


def args(node):
    """Scalar (non-list) tokens after the head, as plain Python values."""
    return [val(c) for c in node[1:] if not isinstance(c, list)]


if __name__ == '__main__':
    print(head(load(sys.argv[1])))
