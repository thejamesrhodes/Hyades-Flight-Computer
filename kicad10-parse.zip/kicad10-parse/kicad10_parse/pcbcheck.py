# SPDX-License-Identifier: Apache-2.0
"""ERC/DRC-lite checks over a populated .kicad_pcb netlist.

Reports (from resolved pad net assignments, KiCad 10 net-name format):
  - unconnected pads                (KiCad 'unconnected-(...)' nets)
  - single-pad named nets           (dead-ends; often intentional spares)
  - multi-pin IC pins with no net    (wiring gaps on real ICs are suspicious)
  - footprints without a 3D model    (grouped; net-ties/holes are expected)
  - rail sanity                      (GND / +3V3 / +5V pad counts)

CLI:  python -m kicad10_parse.pcbcheck board.kicad_pcb
"""
import sys
from collections import defaultdict, Counter
from . import pcb
from .sexp import load, children, get1, args

IC_PREFIX = ('U',)  # refs treated as ICs for the "IC pin has no net" check

def _footprint_models(path):
    """ref -> bool(has (model ...))  and  ref -> lib_id, read from raw tree."""
    t = load(path); has = {}; lib = {}
    for fp in children(t, 'footprint'):
        ref = None
        for pr in children(fp, 'property'):
            a = args(pr)
            if a and a[0] == 'Reference':
                ref = a[1] if len(a) > 1 else ''
        if ref is None:
            continue
        has[ref] = bool(children(fp, 'model'))
        lib[ref] = args(fp)[0] if args(fp) else '?'
    return has, lib

def check(path):
    P = pcb.extract(path); np = P['net_pads']
    fps = {f['ref']: f for f in P['fps'] if f['ref']}
    has_model, libof = _footprint_models(path)
    out = {}

    # unconnected pads
    out['unconnected'] = sorted(
        (n.replace('unconnected-(', '').rstrip(')'), tuple(np[n][0]))
        for n in np if n.startswith('unconnected-'))

    # single-pad named nets (dead-ends)
    singles = [(n, np[n][0]) for n, v in np.items()
               if len(v) == 1 and not n.startswith('unconnected-') and not n.startswith('Net-(')]
    out['single_pad'] = sorted(singles)

    # multi-pin IC pins with no net at all (pad net is None)
    ic_gaps = []
    for ref, f in fps.items():
        if not ref.startswith(IC_PREFIX):
            continue
        if len(f['pads']) < 6:
            continue
        for pad, net in f['pads']:
            if net is None:
                ic_gaps.append((ref, pad))
    out['ic_no_net'] = sorted(ic_gaps)

    # 3D models
    missing = [(r, libof.get(r, '?')) for r, h in has_model.items() if not h]
    out['no_model'] = sorted(missing)
    out['no_model_by_lib'] = Counter(l.split(':')[0] for _, l in missing)

    # rail sanity
    out['rails'] = {r: len(np.get(r, [])) for r in ('GND', '+3V3', '+5V', '+3.3V')}
    out['totals'] = dict(footprints=len(P['fps']), nets=len(np),
                         with_model=sum(has_model.values()),
                         without_model=len(missing))
    return out

def main(argv=None):
    argv = argv or sys.argv[1:]
    if not argv:
        print(__doc__.strip()); return 2
    r = check(argv[0]); T = r['totals']
    print(f"== pcbcheck: {argv[0]} ==")
    print(f"footprints={T['footprints']} nets={T['nets']} "
          f"3D-models: {T['with_model']} present / {T['without_model']} missing")
    print(f"rails (pad counts): {r['rails']}")

    print(f"\n[{len(r['unconnected'])}] UNCONNECTED pads:")
    for name, (ref, pad) in r['unconnected']:
        print(f"    {ref}.{pad}   ({name})")

    print(f"\n[{len(r['ic_no_net'])}] IC pins with NO net (multi-pin U* parts):")
    for ref, pad in r['ic_no_net']:
        print(f"    {ref}.{pad}")

    print(f"\n[{len(r['single_pad'])}] single-pad nets (dead-ends; spares are OK, review the rest):")
    for name, (ref, pad) in r['single_pad']:
        print(f"    {name:28} -> {ref}.{pad}")

    print(f"\n[{len(r['no_model'])}] footprints WITHOUT a 3D model  (by library: "
          f"{dict(r['no_model_by_lib'])}):")
    for ref, lib in r['no_model']:
        print(f"    {ref:6} {lib}")
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
