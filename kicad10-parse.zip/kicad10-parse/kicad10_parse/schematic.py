# SPDX-License-Identifier: Apache-2.0
"""Extract components, hierarchical sheets, and labels from a .kicad_sch file.

CLI:  python -m kicad10_parse.schematic root.kicad_sch [sub.kicad_sch ...] > sch.json
"""
import sys, json
from .sexp import load, children, get1, args


def _prop(sym, name):
    for p in children(sym, 'property'):
        a = args(p)
        if a and a[0] == name:
            return a[1] if len(a) > 1 else ''
    return None


def extract(path):
    """Return a dict: components, hierarchical sheets, and label lists."""
    t = load(path)
    comps = []
    for sym in children(t, 'symbol'):
        li = get1(sym, 'lib_id')
        libid = args(li)[0] if li else None
        props = {}
        for p in children(sym, 'property'):
            a = args(p)
            if len(a) >= 2 and a[0] not in ('Reference', 'Value', 'Footprint', 'Datasheet', 'Description'):
                props[a[0]] = a[1]
        comps.append(dict(
            lib_id=libid,
            ref=_prop(sym, 'Reference'),
            value=_prop(sym, 'Value'),
            footprint=_prop(sym, 'Footprint'),
            datasheet=_prop(sym, 'Datasheet'),
            extra=props,
        ))
    sheets = []
    for sh in children(t, 'sheet'):
        nm = fn = None
        for p in children(sh, 'property'):
            a = args(p)
            if a and a[0] in ('Sheetname', 'Sheet name'):
                nm = a[1] if len(a) > 1 else ''
            if a and a[0] in ('Sheetfile', 'Sheet file'):
                fn = a[1] if len(a) > 1 else ''
        pins = [args(pn)[0] for pn in children(sh, 'pin') if args(pn)]
        sheets.append(dict(name=nm, file=fn, pins=pins))

    def labs(name):
        return sorted({args(l)[0] for l in children(t, name) if args(l)})

    return dict(
        path=path.split('/')[-1],
        components=comps,
        sheets=sheets,
        global_labels=labs('global_label'),
        hier_labels=labs('hierarchical_label'),
        local_labels=labs('label'),
    )


def ref_to_lib(paths):
    """Map reference designator -> lib_id across one or more schematic sheets."""
    r2l = {}
    for p in paths:
        for c in extract(p)['components']:
            if c['ref'] and c['lib_id']:
                r2l[c['ref']] = c['lib_id']
    return r2l


def main(argv=None):
    argv = argv or sys.argv[1:]
    if not argv:
        print(__doc__.strip()); return 2
    print(json.dumps({p.split('/')[-1]: extract(p) for p in argv}, indent=1))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
