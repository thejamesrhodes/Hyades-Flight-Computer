# SPDX-License-Identifier: Apache-2.0
"""Extract pin-number -> pin-name tables from the lib_symbols section.

Recurses into sub-unit symbols, so multi-unit parts are flattened into one
{pad_number: pin_name} table keyed by the library symbol id (e.g.
"MCU_ST_STM32H7:STM32H743VIT6").

CLI:  python -m kicad10_parse.libpins file.kicad_sch [more.kicad_sch ...]
      (prints tables for symbols with >= 6 pins)
"""
import sys, json
from .sexp import load, children, get1, args


def lib_pin_tables(path):
    t = load(path)
    libsec = get1(t, 'lib_symbols')
    tables = {}
    if not libsec:
        return tables
    for sym in children(libsec, 'symbol'):
        name = args(sym)[0]
        pins = {}

        def collect(s):
            for p in children(s, 'pin'):
                nn = get1(p, 'number'); pn = get1(p, 'name')
                num = args(nn)[0] if nn else None
                if num is not None:
                    pins[num] = args(pn)[0] if pn else None
            for sub in children(s, 'symbol'):
                collect(sub)

        collect(sym)
        tables[name] = pins
    return tables


def tables_for(paths):
    """Merge lib pin tables across several schematic files."""
    out = {}
    for p in paths:
        out.update(lib_pin_tables(p))
    return out


def main(argv=None):
    argv = argv or sys.argv[1:]
    if not argv:
        print(__doc__.strip()); return 2
    tabs = tables_for(argv)
    for k, v in tabs.items():
        if len(v) >= 6:
            print(f"### {k}  ({len(v)} pins)")
            for num in sorted(v, key=lambda x: (len(x), x)):
                print(f"   {num}: {v[num]}")
            print()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
