# SPDX-License-Identifier: Apache-2.0
"""Extract the netlist, footprints, zones, stackup and geometry summary from
a .kicad_pcb file.

Connectivity ground truth: in KiCad 10 each pad/track/zone carries its net
NAME directly as (net "NAME"). Returned dict keys:
  copper        list of copper layer names (F.Cu, In1.Cu, ...)
  all_layers    every layer name
  fps           [{lib, ref, value, layer, at:[x,y,rot], pads:[(pad, net)]}]
  net_pads      {net_name: [(ref, pad), ...]}   <- the netlist
  zones         [{net, layers, keepout}]
  bbox          board outline extent from Edge.Cuts, mm {w,h,xmin,...}
  seg_w         {track_width_mm: count}
  via           {"(size, drill)": count}
  track_layers  {layer: segment_count}
  thickness     board thickness, mm

CLI:  python -m kicad10_parse.pcb board.kicad_pcb [out.json]
"""
import sys, json
from .sexp import load, head, children, get1, args, val


def netname(node):
    n = get1(node, 'net')
    if not n:
        return None
    a = args(n)
    return a[-1] if a else None  # single string name in KiCad 10


def extract(path):
    t = load(path)

    layers = []
    lsec = get1(t, 'layers')
    if lsec:
        for l in lsec[1:]:
            if isinstance(l, list):
                a = args(l)            # e.g. (0 "F.Cu" signal) -> ['F.Cu','signal']
                if a:
                    layers.append(a[0])  # layer name is the first scalar after the index
    copper = [l for l in layers if l.endswith('.Cu')]

    fps = []; net_pads = {}
    for fp in children(t, 'footprint'):
        libid = args(fp)[0] if args(fp) else None
        ref = valp = None
        for p in children(fp, 'property'):
            a = args(p)
            if a and a[0] == 'Reference':
                ref = a[1] if len(a) > 1 else ''
            if a and a[0] == 'Value':
                valp = a[1] if len(a) > 1 else ''
        la = get1(fp, 'layer'); layer = args(la)[0] if la else None
        atn = get1(fp, 'at'); at = [float(x) for x in args(atn)] if atn else None
        pads = []
        for pd in children(fp, 'pad'):
            pa = args(pd); padnum = pa[0] if pa else None
            nn = netname(pd)
            pads.append((padnum, nn))
            if nn:
                net_pads.setdefault(nn, []).append((ref, padnum))
        fps.append(dict(lib=libid, ref=ref, value=valp, layer=layer, at=at, pads=pads))

    zones = []
    for z in children(t, 'zone'):
        zl = get1(z, 'layers'); single = get1(z, 'layer'); lys = []
        if zl:
            lys = [val(x) for x in zl[1:] if not isinstance(x, list)]
        elif single:
            lys = [args(single)[0]]
        zones.append(dict(net=netname(z), layers=lys, keepout=bool(get1(z, 'keepout'))))

    xs = []; ys = []
    for g in (t[1:] if isinstance(t, list) else []):
        if isinstance(g, list) and head(g) in ('gr_line', 'gr_arc', 'gr_rect', 'gr_poly', 'gr_circle'):
            ly = get1(g, 'layer')
            if ly and args(ly)[0] == 'Edge.Cuts':
                for pt in ('start', 'end', 'center', 'mid'):
                    n = get1(g, pt)
                    if n:
                        a = args(n)
                        if len(a) >= 2:
                            xs.append(float(a[0])); ys.append(float(a[1]))
                poly = get1(g, 'pts')
                if poly:
                    for xy in children(poly, 'xy'):
                        a = args(xy); xs.append(float(a[0])); ys.append(float(a[1]))
    bbox = None
    if xs and ys:
        bbox = dict(w=round(max(xs) - min(xs), 2), h=round(max(ys) - min(ys), 2),
                    xmin=round(min(xs), 2), xmax=round(max(xs), 2),
                    ymin=round(min(ys), 2), ymax=round(max(ys), 2))

    sw = {}; via = {}; tl = {}
    for s in children(t, 'segment'):
        w = get1(s, 'width'); wv = round(float(args(w)[0]), 3) if w else None
        ly = get1(s, 'layer'); lyv = args(ly)[0] if ly else None
        sw[wv] = sw.get(wv, 0) + 1; tl[lyv] = tl.get(lyv, 0) + 1
    for v in children(t, 'via'):
        sz = get1(v, 'size'); dr = get1(v, 'drill')
        k = (round(float(args(sz)[0]), 3), round(float(args(dr)[0]), 3))
        via[k] = via.get(k, 0) + 1

    gen = get1(t, 'general'); thick = get1(gen, 'thickness') if gen else None
    return dict(copper=copper, all_layers=layers, fps=fps, net_pads=net_pads, zones=zones,
                bbox=bbox, seg_w={str(k): v for k, v in sw.items()},
                via={str(k): v for k, v in via.items()}, track_layers=tl,
                thickness=float(args(thick)[0]) if thick else None)


def pad_to_net(pcb):
    """Invert net_pads -> {(ref, pad): net}."""
    out = {}
    for net, pads in pcb['net_pads'].items():
        for ref, pad in pads:
            out[(ref, str(pad))] = net
    return out


def main(argv=None):
    argv = argv or sys.argv[1:]
    if not argv:
        print(__doc__.strip()); return 2
    r = extract(argv[0])
    if len(argv) > 1:
        with open(argv[1], 'w') as f:
            json.dump(r, f)
    print("copper layers:", r['copper'])
    print("board bbox (mm):", r['bbox'])
    print("thickness (mm):", r['thickness'])
    print("nets:", len(r['net_pads']), "| footprints:", len(r['fps']))
    print("track widths:", r['seg_w'])
    print("vias:", r['via'])
    print("track layer usage:", r['track_layers'])
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
