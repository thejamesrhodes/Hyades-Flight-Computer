# SPDX-License-Identifier: Apache-2.0
"""Schematic hygiene checks over KiCad 10 .kicad_sch files.

Catches the failure modes that a label-driven hierarchical design is prone to:
  - near-miss net names          (edit distance 1: e.g. CS_{2} vs CS_{2}})
  - single-use global labels     (a cross-sheet net used on one sheet only)
  - power symbols whose Value is not a rail name (e.g. a part number)
  - orphan sheet files           (a .kicad_sch not referenced from --root)

CLI:  python -m kicad10_parse.schcheck [--root ROOT.kicad_sch] a.kicad_sch b...
"""
import sys, re, os
from collections import Counter
from .sexp import load, children, get1, args

RAIL = re.compile(r'^(GND|GNDA|GNDD|AGND|DGND|PGND|VSS[A-Z]*|'
                  r'[+\-]?\d+(\.\d+)?V\d*|[+\-]?\d*V\d+|'
                  r'VCC[A-Z0-9_]*|VDD[A-Z0-9_]*|VBAT|VBUS|VREF[+\-]?|'
                  r'\+?\d+V\d*|PWR|Earth)$', re.I)

_STRUCT = set("{}()[]<>| \t.,;:'\"`")  # bracket/punctuation/space = typo-class chars

def _suspicious_near_miss(a, b):
    """Edit distance 1 AND the differing char is a *structural* typo, not an
    intended sibling index. Catches 'CS_{2}' vs 'CS_{2}}' (stray brace) while
    ignoring 'PA0'/'PA1', 'PWM_{1}'/'PWM_{2}', 'USB_{D+}'/'USB_{D-}'."""
    if a == b:
        return False
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if la == lb:  # substitution: flag only if exactly one side is non-alnum
        diffs = [(x, y) for x, y in zip(a, b) if x != y]
        if len(diffs) != 1:
            return False
        x, y = diffs[0]
        return x.isalnum() != y.isalnum()
    # insertion/deletion: flag only if the extra char is a structural char
    if la > lb:
        a, b = b, a
    i = j = 0
    while i < len(a) and a[i] == b[j]:
        i += 1; j += 1
    extra = b[j]           # the inserted character
    return extra in _STRUCT

def collect(paths):
    glob = Counter(); loc = Counter(); powervals = Counter()
    for p in paths:
        t = load(p)
        for l in children(t, 'global_label'):
            if args(l): glob[args(l)[0]] += 1
        for l in children(t, 'label'):
            if args(l): loc[args(l)[0]] += 1
        for sym in children(t, 'symbol'):
            li = get1(sym, 'lib_id'); lib = args(li)[0] if li else ''
            if lib.lower().startswith('power'):
                v = None
                for pr in children(sym, 'property'):
                    a = args(pr)
                    if a and a[0] == 'Value': v = a[1] if len(a) > 1 else ''
                powervals[v] += 1
    return glob, loc, powervals

def referenced_sheets(root):
    """Transitive set of sheet files referenced from root."""
    seen = set(); stack = [root]; base = os.path.dirname(root)
    while stack:
        f = stack.pop()
        if f in seen or not os.path.exists(f):
            continue
        seen.add(f)
        t = load(f)
        for sh in children(t, 'sheet'):
            for pr in children(sh, 'property'):
                a = args(pr)
                if a and a[0] in ('Sheetfile', 'Sheet file') and len(a) > 1:
                    stack.append(os.path.join(base, a[1]))
    return {os.path.abspath(x) for x in seen}

def check(paths, root=None):
    glob, loc, powervals = collect(paths)
    names = sorted(set(glob) | set(loc))
    nearmiss = []
    for i, a in enumerate(names):
        for b in names[i+1:]:
            if _suspicious_near_miss(a, b):
                nearmiss.append((a, glob.get(a, 0)+loc.get(a, 0),
                                 b, glob.get(b, 0)+loc.get(b, 0)))
    badpower = sorted(v for v in powervals if v is None or not RAIL.match(str(v)))
    orphans = []
    if root:
        refd = referenced_sheets(root)
        for p in paths:
            if os.path.abspath(p) not in refd:
                orphans.append(os.path.basename(p))
    return dict(nearmiss=nearmiss, bad_power=badpower,
                orphans=orphans, powervals=dict(powervals))

def main(argv=None):
    argv = argv or sys.argv[1:]
    root = None; files = []
    it = iter(argv)
    for a in it:
        if a == '--root':
            root = next(it, None)
        else:
            files.append(a)
    if not files:
        print(__doc__.strip()); return 2
    r = check(files, root)
    print("== schcheck ==")
    print(f"\n[{len(r['nearmiss'])}] NEAR-MISS net names (likely accidental splits):")
    for a, ca, b, cb in r['nearmiss']:
        print(f"    {a!r} (x{ca})  ~  {b!r} (x{cb})")
    print(f"\n[{len(r['bad_power'])}] power symbols with a non-rail Value:")
    for v in r['bad_power']:
        print(f"    {v!r}")
    if root:
        print(f"\n[{len(r['orphans'])}] ORPHAN sheet files (not referenced from {os.path.basename(root)}):")
        for o in r['orphans']:
            print(f"    {o}")
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
