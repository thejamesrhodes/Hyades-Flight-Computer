# SPDX-License-Identifier: Apache-2.0
"""Schematic net tracer for KiCad 10 hierarchical schematics.

Builds nets from wires + junctions + labels + power ports + rotated/mirrored
symbol pin geometry, then merges global-label / power nets across sheets.
Connectivity ground truth when the PCB is not yet annotated.

Convention auto-calibration: the library->schematic pin transform sign
convention is chosen per run by maximizing pin-on-wire-endpoint coincidence.
"""
import sys, math, glob, os
from collections import defaultdict
from .sexp import load, head, children, get1, args, val

Q = 100.0  # quantize to 0.01 mm
def qpt(x, y): return (round(x*Q)/Q, round(y*Q)/Q)

class UF:
    def __init__(self): self.p={}
    def find(self,a):
        self.p.setdefault(a,a)
        while self.p[a]!=a: self.p[a]=self.p[self.p[a]]; a=self.p[a]
        return a
    def union(self,a,b): self.p[self.find(b)]=self.find(a)

def lib_units(t):
    """(lib_id, unit) -> [(pinnum, pinname, px, py, angle)] from lib_symbols."""
    out=defaultdict(list); libsec=get1(t,'lib_symbols')
    if not libsec: return out
    for sym in children(libsec,'symbol'):
        libid=args(sym)[0]
        for sub in children(sym,'symbol'):
            subname=args(sub)[0]
            parts=subname.split('_')
            unit=1
            if len(parts)>=2 and parts[-2].isdigit(): unit=int(parts[-2])
            for p in children(sub,'pin'):
                at=get1(p,'at'); a=[float(x) for x in args(at)] if at else [0,0,0]
                nn=get1(p,'number'); pn=get1(p,'name')
                num=args(nn)[0] if nn else None
                name=args(pn)[0] if pn else None
                if num is not None:
                    out[(libid,unit)].append((num,name,a[0],a[1],a[2] if len(a)>2 else 0))
    return out

def place_pin(sx,sy,srot,mirror,px,py,conv):
    """Transform a lib pin (px,py) to absolute schematic coords."""
    th=math.radians(srot)
    c,s=math.cos(th),math.sin(th)
    # rotate (CCW)
    rx=px*c-py*s; ry=px*s+py*c
    # mirror in library frame
    if mirror=='x': ry=-ry
    if mirror=='y': rx=-rx
    # Y-flip convention (lib Y-up vs sch Y-down): conv picks the sign
    if conv==0:  ax=sx+rx; ay=sy-ry
    else:        ax=sx+rx; ay=sy+ry
    return qpt(ax,ay)

def parse_sheet(path):
    t=load(path); units=lib_units(t)
    syms=[]  # (ref, unit, lib, at, mirror, is_power, value)
    for sym in children(t,'symbol'):
        li=get1(sym,'lib_id'); lib=args(li)[0] if li else None
        at=get1(sym,'at'); a=[float(x) for x in args(at)] if at else [0,0,0]
        un=get1(sym,'unit'); unit=int(args(un)[0]) if un else 1
        mr=get1(sym,'mirror'); mirror=args(mr)[0] if mr else None
        ref=valp=None
        for p in children(sym,'property'):
            pa=args(p)
            if pa and pa[0]=='Reference': ref=pa[1] if len(pa)>1 else ''
            if pa and pa[0]=='Value': valp=pa[1] if len(pa)>1 else ''
        is_power = bool(lib and lib.lower().startswith('power'))
        syms.append(dict(ref=ref,unit=unit,lib=lib,at=(a[0],a[1]),rot=a[2] if len(a)>2 else 0,
                         mirror=mirror,is_power=is_power,value=valp))
    wires=[]
    for w in children(t,'wire'):
        pts=get1(w,'pts')
        xy=[args(p) for p in children(pts,'xy')] if pts else []
        if len(xy)>=2: wires.append((qpt(float(xy[0][0]),float(xy[0][1])),
                                     qpt(float(xy[1][0]),float(xy[1][1]))))
    junc=[qpt(float(args(get1(j,'at'))[0]),float(args(get1(j,'at'))[1])) for j in children(t,'junction')]
    def labelset(tag):
        r=[]
        for l in children(t,tag):
            at=get1(l,'at'); a=args(at); r.append((qpt(float(a[0]),float(a[1])), args(l)[0]))
        return r
    return dict(units=units,syms=syms,wires=wires,junc=junc,
                local=labelset('label'),glob=labelset('global_label'),path=os.path.basename(path))

def build(paths, conv):
    uf=UF(); pin_at={}; # (sheet,ref,unit,pinnum)->pt
    sheet_local={}   # (sheet, pt)->set localnames
    global_at=defaultdict(list) # netname->list of pts (global scope)
    pin_index=defaultdict(list) # pt(sheet-tagged)->list of (ref,pin,name)
    node_net=defaultdict(set)   # pt(sheet-tagged) -> local label names
    sheets=[parse_sheet(p) for p in paths]
    coincidence=0; total_pins=0
    for sh in sheets:
        S=sh['path']
        def tag(pt): return (S,pt)
        for (a,b) in sh['wires']: uf.union(tag(a),tag(b))
        for j in sh['junc']: pass
        wire_pts=set()
        for (a,b) in sh['wires']: wire_pts.add(a); wire_pts.add(b)
        # component pins
        for sym in sh['syms']:
            if sym['is_power']:
                # power symbol: single pin -> its net name is value; place its pins
                for (num,name,px,py,pang) in sh['units'].get((sym['lib'],sym['unit']),[]):
                    pt=place_pin(sym['at'][0],sym['at'][1],sym['rot'],sym['mirror'],px,py,conv)
                    uf.union(tag(('pwr',sym['value'],pt)),tag(pt))
                    global_at[sym['value']].append(tag(pt))
                continue
            for (num,name,px,py,pang) in sh['units'].get((sym['lib'],sym['unit']),[]):
                pt=place_pin(sym['at'][0],sym['at'][1],sym['rot'],sym['mirror'],px,py,conv)
                pin_index[tag(pt)].append((sym['ref'],num,name))
                pin_at[(S,sym['ref'],sym['unit'],num)]=pt
                total_pins+=1
                if pt in wire_pts: coincidence+=1
                uf.union(tag(('pin',S,sym['ref'],sym['unit'],num)),tag(pt))
        for (pt,txt) in sh['local']:
            uf.union(tag(('lbl',txt,pt)),tag(pt)); node_net[tag(pt)].add(txt)
        for (pt,txt) in sh['glob']:
            uf.union(tag(('glb',txt,pt)),tag(pt)); global_at[txt].append(tag(pt))
    # merge global/power nets across sheets by name
    for name,pts in global_at.items():
        base=('GLOBAL',name)
        for p in pts: uf.union(base,p)
    return uf,pin_index,node_net,global_at,pin_at,(coincidence,total_pins),sheets

def net_of(uf,node_net,global_at, node):
    # name priority: global/power name if this root is a global base, else local label
    root=uf.find(node)
    return root

def run(paths):
    best=None
    for conv in (0,1):
        uf,pin_index,node_net,global_at,pin_at,(co,tp),sheets=build(paths,conv)
        best=best if best and best[0][0]>=co else ((co,tp),conv,uf,pin_index,node_net,global_at,pin_at,sheets)
    (co,tp),conv,uf,pin_index,node_net,global_at,pin_at,sheets=best
    # name each root
    root_name={}
    for name,pts in global_at.items():
        r=uf.find(('GLOBAL',name)); root_name[r]=name
    # local labels name their component (only if no global)
    for (S,pt),names in node_net.items():
        r=uf.find((S,pt))
        if r not in root_name: root_name[r]=sorted(names)[0]
    def netname(S,ref,unit,num):
        pt=pin_at.get((S,ref,unit,num))
        if pt is None: return None
        r=uf.find((S,pt)); return root_name.get(r, f'N${r if isinstance(r,str) else "?"}')
    return dict(conv=conv,coincidence=co,total=tp,uf=uf,root_name=root_name,
               pin_at=pin_at,netname=netname,sheets=sheets,global_at=global_at)

if __name__=='__main__':
    paths=sys.argv[1:]
    R=run(paths)
    print(f"conv={R['conv']} pin-on-wire coincidence={R['coincidence']}/{R['total']} "
          f"({100*R['coincidence']/max(R['total'],1):.0f}%)")
    # net sizes (sanity)
    from collections import Counter
    c=Counter()
    for (S,ref,unit,num),pt in R['pin_at'].items():
        c[R['netname'](S,ref,unit,num)]+=1
    print("Top nets by pin count:")
    for name,n in c.most_common(15):
        print(f"   {str(name)[:28]:28} {n}")
