# SPDX-License-Identifier: Apache-2.0
"""kicad10-parse: a dependency-free reader for KiCad 10 .kicad_sch / .kicad_pcb files.

KiCad 10 (sch format 20260306, pcb format 20260206) stores each net's *name*
directly on every pad/track/zone as (net "NAME"); there is no integer net table.
This package treats that net name as ground truth for connectivity.
"""
from .sexp import load, head, children, get1, args, val, find_all  # noqa: F401

__version__ = "0.2.0"
